<?php
require_once("dataset.php");
$sel = new dataset();
$Address = " adress: 5 El-Montaza, El-Nozha, El Nozha, Cairo Governorate, Egypt";
$sel->select($Address);
// $sel->$Address =$_POST['Address'];
// $sel->select($_POST['Address']);
?>
