<?php
require "db.php";
class dataset{
    public $id;
    public $u_id;
    public $image;
    public $Address; 
      // public $Address = " adress: Street 257, Maadi as Sarayat Al Gharbeyah, Al Maadi, Cairo Governorate, Egypt";
    public $result_id;
    public $result1_id;
    public $name;

    public function insert($us_id,$img,$addres,$reid,$re2id,$name)
    {
        $DBobject = new DB();
        $sql = "INSERT INTO dataset (`u_id`, `image`, `Address`, `result_id`, `result1_id`, `name`)  VALUES
        ('".$us_id."','".$img."','".$addres."','".$reid."','".$re2id."','".$name."')";
        $DBobject->connect();
        $DBobject->execute($sql);
        $DBobject->disconnect();
    }
    
    public function select($address){
        $DBobject = new DB();
        $sql = "SELECT  `result_id` , `result1_id` FROM dataset WHERE Address = '".$address."' ";
        //echo $sql;
        $DBobject->connect();
        $result = $DBobject->execute($sql);
        while ($row = mysqli_fetch_array($result)){
            //echo "123";
            echo $row[0];
            echo "~";
            echo $row[1];
           // echo $row['result1_id'];
        }
        $DBobject->disconnect();
    }
    /*
    public function update(){
        $DBobject = new DB();
        $sql = "UPDATE dataset SET result_id='".$this->result_id."' WHERE id = '".$this->id."'";
        $DBobject->connect();
        $DBobject->execute($sql);
        $DBobject->disconnect();

    }
*/
}
?>